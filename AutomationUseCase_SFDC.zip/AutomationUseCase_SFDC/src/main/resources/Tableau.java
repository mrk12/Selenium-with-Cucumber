
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
//import ru.yondex.qatools.ashot.AShot;


import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;

public class CssComparison {
	public static WebDriver driver=null;
	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rmanchik\\Documents\\CPQ\\chromedriver.exe"); 
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         driver.get("https://tableau.cloud.digital.ge.com/#/views/ProjectPermissionAssignmentsbyIDMGroup/ProjectPermissionAssignmentGroups?:iid=1");
         driver.findElement(By.xpath("//*[@id='username']")).sendKeys("503088227");
         driver.findElement(By.xpath("//*[@id='password']")).sendKeys("Igate@123ge");
         driver.findElement(By.xpath("//*[@id='submitFrmShared']")).click();
         validCase();
        // imageCompare();         
         Thread.sleep(30000);
         driver.close();
	}
	
	
	public static void validCase(){
		Map<String, String> Book = new HashMap<>();
		 WebElement BookTab = driver.findElement(By.xpath("//*[@id='tab-ui-id-5']/span[2]/div/span")); 
		 Book.put("color", BookTab.getCssValue("color"));		 		
		 Book.put("size", BookTab.getCssValue("font-size"));
		 Book.put("familyType", BookTab.getCssValue("font-family"));
		 
       Map<String, String> Deals = new HashMap<>();       
       WebElement DealsTab = driver.findElement(By.xpath("//*[@id='ng-app']/div/div/div/div[1]/div/div[1]/span[1]/nav/ol/li[4]/span")); 
       Deals.put("color", DealsTab.getCssValue("color"));		 		
		Deals.put("size", DealsTab.getCssValue("font-size"));
		Deals.put("familyType", DealsTab.getCssValue("font-family"));
		
		 	
		Assert.assertEquals(Deals.get("color"), Book.get("color"), "Color not matched");
		Assert.assertEquals(Deals.get("size"), Book.get("size"), "Size not matched");
		Assert.assertEquals(Deals.get("familyType"), Book.get("familyType"), "FamilyType not matched");
		 
		
		/*if(Deals.get("color").equals(Book.get("color"))){
			System.out.println("Color matched");
		}*/
	}
	
//	public static void imageCompare() throws IOException{
//		WebElement webElement = driver.findElement(By.cssSelector("//*[@id='tabZoneId10']/div/div/div/div[1]/div/span/div/span"));
//		Screenshot screenshot= new AShot().takeScreenshot(driver, webElement);
//		ImageIO.write(screenshot.getImage(), "PNG", new File(System.getProperty("user.dir")+"C:\\Users\\rmanchik\\Documents\\ICAM\\Element.png"));
//		
//	}
//	
//	public static void invalidCase(){
//		Map<String, String> Book = new HashMap<>();
//		 WebElement BookTab = driver.findElement(By.xpath("//div[@id='smoothmenu1']/ul/li[5]")); 
//		 Book.put("color", BookTab.getCssValue("color"));		 		
//		 Book.put("size", BookTab.getCssValue("font-size"));
//		 Book.put("familyType", BookTab.getCssValue("font-family"));
//		 
//        Map<String, String> Flights = new HashMap<>();       
//        WebElement RoundtripText = driver.findElement(By.xpath("//div[@id='buttons']/div/div/ul/li[1]")); 
//        Flights.put("color", RoundtripText.getCssValue("color"));		 		
//        Flights.put("size", RoundtripText.getCssValue("font-size"));
//        Flights.put("familyType", RoundtripText.getCssValue("font-family"));
//		System.out.println(Flights);
//		/*Assert.assertEquals(Flights.get("familyType"), Book.get("familyType"), "Color not matched"); 	
//		Assert.assertEquals(Flights.get("color"), Book.get("color"), "Color not matched"); 
//		Assert.assertEquals(Flights.get("size"), Book.get("size"), "Size not matched"); */
//		if(Flights.get("color").equals(Book.get("color"))){
//			System.out.println("Color matched");
//		}
//		else{
//			System.out.println(" color not matched");
//		}
//	}
	
	
}// Main Class
