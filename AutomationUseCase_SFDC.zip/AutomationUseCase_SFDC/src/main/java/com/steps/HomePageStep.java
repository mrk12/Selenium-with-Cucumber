package com.steps;

import java.io.IOException;

import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.pages.HomePage;
import com.util.Setup;
import com.util.TestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomePageStep{

	
	Steps steps;	
	
	public HomePageStep(Steps steps) {
		this.steps=steps;
	}
	

		    

	
}
