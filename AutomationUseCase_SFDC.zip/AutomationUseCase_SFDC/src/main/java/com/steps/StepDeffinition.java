package com.steps;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.util.Setup;
import com.util.TestBase;
import com.util.WebDriverUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDeffinition {

	 Steps steps;	
	
	public StepDeffinition(Steps steps) {
		this.steps=steps;
	}
	
	
	/*@Then("^User able to enter valid Credentials as TM$")
	public void enter_SSO() throws IOException {
		Reporter.addStepLog("Step Log message goes here");
		steps.loginPage.ssoUserName(Setup.username_TM);
		steps.loginPage.ssoPwd(Setup.pwd_TM);
		steps.loginPage.loginSubmitBtn();
		Reporter.addScreenCaptureFromPath("absolute screenshot path");
	}
	
	@Then("^User should able to successfuly navigate into Home page1$")
	public void verifyHomepageOptionText() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.verifyHomeTextIsPresent();
		 
	}*/
	
	@When("^User on home page click on app launcher icons$")
	public void user_on_home_page_click_on_app_launcher_icon() throws Throwable {
		steps.applaunchPage = steps.homePage.clickOnAppLauncherIcon();
		steps.oppoPage = steps.applaunchPage.clickOnOpportunities();
		steps.oppoDetailPage = steps.oppoPage.selectOpportunity();
		steps.oppoDetailPage.clickonOCPQ();
		steps.createQuotePage = steps.oppoDetailPage.clickOnNew();
		steps.createQuotePage.searchCloudSite();
		steps.createQuotePage.selectSite();
		steps.quoteInformPage = steps.createQuotePage.clickOnCreateQuoteButton();
		steps.quoteInformPage.switchToFrame();
		steps.quoteInformPage.selectRepairs();
		steps.quoteInformPage.selectEngineeredSolutions();
		steps.quoteInformPage.selectQuoteType();
		steps.quoteInformPage.selectPraposalType();
		steps.quoteInformPage.enterProposalTile();
		steps.quoteInformPage.clickOnSaveButton();
		steps.quoteInformPage.sendRequestToAEM();
		
	}
	
	@Then("^User can search for quote number$")
	public void user_can_search_for_quote_number() throws Throwable {
		steps.aepage=steps.testBase.aepage();
		//steps.quoteInformPage = steps.homePage.openCreatedQuote();
		//steps.quoteInformPage.switchToFrameForAE();
		//steps.quoteInformPage.clickOnApplicationEngineerTab();
		steps.quoteInformPage.selectTRSPlanStatus();
		steps.quoteInformPage.selectMaterialRequiredDropdown();
		steps.quoteInformPage.selectSeamConditionDropdown();
		steps.quoteInformPage.selectExceptionsToBidSpecDropdown();
		steps.quoteInformPage.chooseTechnicalRiskcheckBox();
		//steps.quoteInformPage.submitButton();
		steps.aepage.clickOnSave();
		
		steps.aepage.bomtab();
		/*steps.quoteInformPage.clickOnBOmUploadTab();
		//steps.quoteInformPage.clickOnRemoveCheckBox();
		steps.quoteInformPage.uploadFile();
		//steps.quoteInformPage.clickOnSaveButton();
*/		
	}
	
	//SFDC Project Code
	
	
	@Then("^User able to enter valid Credentials$")
	public void enter_SSO() throws IOException {
		//Reporter.addStepLog("Step Log message goes here");
		steps.loginPage.ssoUserName(Setup.username);
		steps.loginPage.ssoPwd(Setup.pwd);
		steps.loginPage.loginSubmitBtn();
		//Reporter.addScreenCaptureFromPath("absolute screenshot path");
	}
	
	@Then("^User should able to successfuly navigate into HomePage$")
	public void verifyHomepageOptionText() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.verifyHomeTextIsPresent();
		 
	}
	
	@Then("^User should able to click on More Option$")
	public void clickONMore() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnMoreOption();		 
	}
	@Then("^User should able to click on Reports Option$")
	public void clickONMoreReports() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnMoreReportOption();		 
	}
	@Then("^User should able to select report type as Accounts$")
	public void clickOnNewReport() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnNewReport();		 
	}
	@Then("^User should able to switch to Accounts tab$")
	public void switchToAccountsFrame() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.switchToAccountsFrame();		 
	}
	@Then("^User should able to switch to Second Accounts tab$")
	public void switchToAccountsSecondFrame() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.switchToAccountsSecondFrame();		 
	}
	@Then("^User should able to add First Level KEY Fields$")
	public void clickOnAddBtn() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnAddBtn();		 
	}
	@Then("^User should able to Save the Report$")
	public void clickOnSaveReport() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnSaveReport();		 
	}
	@Then("^User should able to Run the Report$")
	public void clickOnRunReportsBtn() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnRunReportsBtn();		 
	}
	
	@Then("^User should able to navigates to Reports Page$")
	public void clickOnReportsTab() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnReportsTab();		 
	}
	@Then("^User should able to add Second Level KEY Fields$")
	public void clickOnSecondAddBtn() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnSecondAddBtn();		 
	}
	
	@Then("^User should able to add Third Level KEY Fields$")
	public void clickOnThirdAddBtn() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.clickOnThirdAddBtn();		 
	}
	
	
	
	@Then("^User should click on third Opportunities Tab$")
	public void user_should_clickOpportunities_Tab() throws Throwable {
		 steps.homePage = steps.testBase.homepage();
		 steps.homePage.ThirdEditTest();
		 //steps.homePage.openOpportunity();
		 steps.homePage.clilckOnReverseDealMngmnt1();
		 //steps.homePage.editOpportunity();
		 steps.homePage.clickOnDadshBoradTab();
		 steps.homePage.clickOnMasterTerms();
		 steps.homePage.validateThirdReport();
	}
	

	@Then("^User should click on Opportunities Tab$")
	public void user_should_click_on_Opportunities_Tab() throws Throwable {
		 steps.homePage = steps.testBase.homepage();
		 steps.homePage.clickOnOpportunities();
		 steps.homePage.clickOnNewBtn();
		 steps.homePage.enterOpportunityname();
		 steps.homePage.searchForproject();
		 steps.homePage.selectAccount();
		 steps.homePage.selectEndUSer();
		 steps.homePage.selectfromInstallCountryDropdown();
		 steps.homePage.selectFromStagedropdown();
		 steps.homePage.selectProposalType();
		 steps.homePage.selectProjectScope();
		 steps.homePage.selectTier3PL();
		 steps.homePage.selectExpectOrderDate();
		 steps.homePage.selectEquityOrFinance();
		 steps.homePage.clickOnSaveButton();
		 
		 steps.homePage.clickOnDealManagement();
		 steps.homePage.editOpportunity();
		 steps.homePage.selectTermsConditionsdropdwon();
		 steps.homePage.selectOnshoreOffshore();
		 steps.homePage.clickOnSaveButton();
		 steps.homePage.clickOnCancel();
		 steps.homePage.clickOnDadshBoradTab();		 
		 steps.homePage.clickOnMasterTerms();
		 steps.homePage.validateFirstReport();
		 
		 steps.homePage.navigateToOpportunity();
		 steps.homePage.clickOnKeyPlayers();
		 steps.homePage.clickOnNewButton();
		 steps.homePage.chooseSecondPreCondition();
		 steps.homePage.chooseKeyRole();
		 steps.homePage.clickOnSaveButton();
		 
		 steps.homePage.openOpportunity();
		 steps.homePage.clilckOnReverseDealMngmnt();
		 steps.homePage.editOpportunity();
		 steps.homePage.clickOnDadshBoradTab();
		 steps.homePage.clickOnMasterTerms();
		 steps.homePage.validateSecondReport();
		 
	}
	
	@Then("^User should able to create new tab$")
	public void newTabCreation() throws InterruptedException {
		  steps.homePage = steps.testBase.homepage();
		  steps.loginPage.newTabCreation();		 
	}
	

	
	
	
	
	
	
	
	
		    

	
}
