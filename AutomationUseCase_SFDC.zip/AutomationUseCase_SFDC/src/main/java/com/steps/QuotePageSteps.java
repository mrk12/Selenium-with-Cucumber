package com.steps;

import java.util.concurrent.TimeoutException;

import com.util.Setup;
import com.util.WebDriverUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class QuotePageSteps {

	Steps steps;
	
	public QuotePageSteps(Steps steps) {
		this.steps=steps;
	}
	
	@Then("^User Search for the Quote by passing Quote number$")
	public void searchQuote() {
		steps.quotePage=steps.testBase.quotePage();
		steps.quotePage.SearchForQuote(WebDriverUtils.quoteNum);
	}
	
	@Then("^User click on Action icon in Quote and User click on Edit option$")
	public void Click_on_Edit() {
		steps.quotePage.clickDropDownForOptions();
		steps.quotePage.clickEdit();
	}
	
	@Then("^User navigate to the Oracle CPQ Quote page$")
	public void verifyCPQQuotePageDisplay() throws TimeoutException {
		steps.quotePage.waitForQuotePagetoLoad();
	}
	
	@Then("^User clicked on the AEM tab$")
	public void click_on_AEMTab() {
		steps.quotePage.minimizeGITab();
		steps.quotePage.clickOnAEM();
	}
	
	@Then("^User User is able to see the AEM fields$")
	public void verify_AEM_fields() {
		steps.quotePage.verifyAEMFields();
	}
	
	@Then("^User filled the all required details$")
	public void aem_Req_Details() {
		steps.quotePage.fillReqDetails("Test",steps.quotePage.getdate());
	}
	
	@Then("^User Approve the Request$")
	public void approve_Request() {
		steps.quotePage.approveReq();
	}
	@Then("^User submitted the required details$")
	public void enter_Req_details() {
		steps.quotePage.fillApprovalReqDetails();
	}
	
	@Then("^User approved the request submitted by AE$")
	public void approve_TechDetails() {
		steps.quotePage.approveReq();
	}
	
	@When("User Quote current status is (.*)$")
	public void validate_Current_status(String status) {
		steps.quotePage.validateQuoteStatus(status);
	}
	
	@Then("User minimized the General information and opens the AEM tab")
	public void open_AEM_tab() {
		steps.quotePage.minimizeGITab();
		steps.quotePage.clickOnAEM();
	}
	
	@Then("^User is able to see the Request submitted by AEM in BOM Mgmt tab$")
	public void clickOn_BOMApproval_mgmt_tab() {
		
		
	}
}
