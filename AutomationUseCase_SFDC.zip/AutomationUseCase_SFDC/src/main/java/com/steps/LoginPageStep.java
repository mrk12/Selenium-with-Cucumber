package com.steps;

import java.io.IOException;

import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.util.Setup;
import com.util.TestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStep{

	
	Steps steps;	
	
	public LoginPageStep(Steps steps) {
		this.steps=steps;
	}
	
	@Given("^User launch browser$")
	public void user_launch_browser() {
		steps.testBase=new TestBase();
		steps.testBase.initilizeDriver();
	}
	
	@When("^User enter url$")
	public void enter_url() {
		steps.loginPage=steps.testBase.enterURL(Setup.AUTOMATION_URL);
	}
	
	@Then("^User able to enter valid Credentials as AE$")
	public void login_AE() throws IOException {
		
		Reporter.addStepLog("Step Log message goes here");
			
		steps.loginPage.ssoUserName(Setup.username_AE);
		steps.loginPage.ssoPwd(Setup.pwd_AE);
		steps.loginPage.loginSubmitBtn();
		Reporter.addScreenCaptureFromPath("absolute screenshot path");
	}
	
	@Then("^User able to enter valid Credentials as AEM$")
	public void login_AEM() throws IOException {
		
		Reporter.addStepLog("Step Log message goes here");
			
		steps.loginPage.ssoUserName(Setup.username_AEM);
		steps.loginPage.ssoPwd(Setup.pwd_AEM);
		steps.loginPage.loginSubmitBtn();
		Reporter.addScreenCaptureFromPath("absolute screenshot path");
	}
	
	@Then("^User should able to successfuly navigate into Home page$")
	public void verifyHomepageOptionText() {
		Assert.assertTrue(steps.loginPage.verifyHomeTextIsPresent());
	}
	
	/*@Then("^User should able to accept alert message$")
	public void acceptAlertMessage() {
		//steps.loginPage.alertMessageAccept();	
	}
	*/
	
	@When("^User on home page click on app launcher icon$")
	public void navigateToAppLauncherWindow() {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.clickOnAppLauncherIcon();
}
	
	@When("^User is able to to close the browser$")
	public void clsoeWindow() {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.closeWindow();
}
	
	@When("^User is able to click on Opportunity Tab$")
	public void clickOnOpportunityTab() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.clickOnOpportunityTab();
}
	@When("^User is able to click on Opportunity$")
	public void opportunity() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.opportunity();
}
	
	@When("^User is able to enter on Opportunity name$")
	public void opportunityName() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.opportunityName();
}
	@When("^User is able to enter on date and save opportunity$")
	public void date() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.date();
}
	@When("^User is able to create anew keyplayer$")
	public void newkeyplayer() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.newkeyplayer();
}
	@When("^User is able to create a new meeting$")
	public void newmeeting() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.newmeeting();
}
	
	@When("^User is able to create a new riskmodule$")
	public void newriskmodule() throws InterruptedException {	
		//HomePage homePage = new HomePage(driver);
		steps.loginPage.newriskmodule();
}

	
}
