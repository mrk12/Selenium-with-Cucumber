package com.steps;

import java.util.concurrent.TimeoutException;


import com.util.Setup;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AEQuoteSteps {

Steps steps;
	
	public AEQuoteSteps(Steps steps) {
		this.steps=steps;
	
}
	
	@Then("^User click on AE tab$")
	public void go_To_AETab() throws InterruptedException, TimeoutException {
		steps.quotePage=steps.testBase.quotePage();
		steps.aepage=steps.testBase.aepage();
		steps.quotePage.minimizeGITab();
		steps.aepage.clickOnAETab();
		   steps.aepage.enterTechnicltext();
		   steps.aepage.setMaterialReq();
		   steps.aepage.setSMEDetails();
		   steps.aepage.setExceptionBid();
		   steps.aepage.setTrsPlan();
		   steps.aepage.setTags();
		   steps.aepage.clickOnSave();
		   steps.aepage.bomtab();
		   steps.quotePage.waitForQuotePagetoLoad();
	}
	
	@Then("^User clicked on the Legacy Tab$")
	public void clickOnLegacyGas() {
		steps.aepage.selectLegacyTab();
	}
	
	@Then("^User clicked on Generate Proposal button$")
	public void selectGenerateProposalBtn() {
		steps.aepage.clickGenerateProposal();
	}
	
	@Then("^User clicked on Publish now button$")
	public void clickPublishBtn() {
		steps.aepage.switchWindow();
		steps.aepage.clickOnPublishNow();
	}
	
	@Then("User refreshed the window")
	public void refreshWindow() throws TimeoutException {
		steps.aepage.switchWindow();
		steps.aepage.refreshWin();
		steps.quotePage.waitForQuotePagetoLoad();
		steps.quotePage.minimizeGITab();
		
	}
	
	@Then("^User is able to see the Proposal URL in Legacy Gas tab$")
	public void verify_Proposal_URL() throws InterruptedException { 
	   steps.aepage.selectLegacyTab();
	    steps.aepage.verifyProposalURL();
	}
	
	@Then("^User is able to see the attached Engineer template$")
	public void verify_attached_template() {
		steps.aepage.clickOnLegacyTech();
		steps.aepage.verifyTemplateDisplay(Setup.quote_No);
	}
	
	@Then("^User clicked on the Customer proposal tab$")
	public void click_customerProposal() {
		steps.aepage.clickOnCustomerProposaltab();
	}
	
	@Then("^User entered the Group discussion details and saved the details$")
	public void enter_GroupDetails_AndSave() {
		steps.aepage.enterGroupName(Setup.group_Name);
		steps.aepage.enterGroupDesc(Setup.group_Desc);
		steps.aepage.clickOnSave();
	}
	
	@Then("^User clicked on AE tab$")
	public void go_to_AE() {
		steps.quotePage.maximizeGITab();
		
	}
	
	@Then("^User submit to AEM$")
	public void submit_to_AEm(){
		steps.aepage.clickSubmitTOAEM();
		steps.aepage.clickSubmitInPopup();
	}
	
	@Then("^User get the updated quote (.*)$")
	public void updatedQuoteStatus(String status) {
		steps.quotePage.validateQuoteStatus(status);
	}
	
}
