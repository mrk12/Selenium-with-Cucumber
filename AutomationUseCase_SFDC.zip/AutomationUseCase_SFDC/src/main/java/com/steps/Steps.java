package com.steps;


import com.pages.AEPage;
import com.pages.AppLauncher;
import com.pages.CreateQuotePage;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.pages.OppoDetailsPage;
import com.pages.OpportunitiesPage;
import com.pages.QuoteInformationPage;
import com.pages.QuotePage;
import com.util.TestBase;

public class Steps {
	
	public TestBase testBase;
	public LoginPage loginPage;
	public HomePage homePage;
	public AppLauncher applaunchPage;
	public OpportunitiesPage oppoPage;
	public OppoDetailsPage oppoDetailPage;
	public CreateQuotePage createQuotePage;
	public  QuoteInformationPage quoteInformPage;
	public QuotePage quotePage;
	public AEPage aepage;
	
}
