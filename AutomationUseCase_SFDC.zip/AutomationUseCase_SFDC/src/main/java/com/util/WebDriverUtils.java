package com.util;

import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.itextpdf.text.List;

public class WebDriverUtils {

	WebDriver driver;
    public static String quoteNum;
	public WebDriverUtils(WebDriver driver) {
		this.driver = driver;
	}

	public void staticWait(int time) {
		System.out.println("Total time to wait :: " + time + " sec..");
		try {
			for (int t = 1; t <= time; t++) {
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void checkAlert() {
		try {

			WebDriverWait wait = new WebDriverWait(driver, 5);

			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				Alert alert = driver.switchTo().alert();
				alert.accept();
			} else {
				System.out.println("No Alert Present");
			}

		} catch (Exception e) {
			// exception handling
		}
	}

	public void click(By prop) {
		new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(prop));
		driver.findElement(prop).click();
	}
	public void clear(By prop) {
		new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOfElementLocated(prop));
		driver.findElement(prop).clear();
	}

	public void enterText(By prop, String testData) {
		new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(prop));
		driver.findElement(prop).clear();
		driver.findElement(prop).sendKeys(testData);
	}

	public void selectValueFromDropDown(By prop, String value) {
		new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(prop));
		new Select(driver.findElement(prop)).selectByValue(value);
	}

	public void selectValueFromDropDown(By prop, int index) {
		new Select(driver.findElement(prop)).selectByIndex(index);
	}

	public String getText(By prop) {
		new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(prop));
		return driver.findElement(prop).getText();
	}

	public void doMouseHover(By prop) {
		Actions builder = new Actions(driver);
		new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(prop));
		builder.moveToElement(driver.findElement(prop)).build().perform();
	}

	public void clickUsingJavaScript(By prop) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(prop));
	}

	public void clickUsingActions(By prop) {

		Actions builder = new Actions(driver);
		new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(prop));
		builder.moveToElement(driver.findElement(prop)).click().build().perform();
	}

	public void clickUsingSubmit(By prop) {
		driver.findElement(prop).submit();
	}

	public void selectFrame(By prop) {
		//(new WebDriverWait(driver, 15)).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(prop));
		driver.switchTo().frame(driver.findElement(prop));
	}
	public void selectFrameByIndex(int index) {
		driver.switchTo().frame(index);	
	}

	public void pageScroll() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 250);");

	}

	public boolean isElementPresent(By prop) {
		new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(prop));
		return driver.findElement(prop).isDisplayed();
	}

	public void enterTab() throws InterruptedException {
		Thread.sleep(1000);
		Actions action = new Actions(driver);
		action.sendKeys(Keys.TAB).build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
	}
	
	public void switchToWindow(int index) {
		ArrayList<String> windows = new  ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(windows.get(index));
	}
	
	public String getlabelText(By prop) {
		return driver.findElement(prop).getText();
	}
	
	public void displayAssertion(By prop) {
		Assert.assertTrue(driver.findElement(prop).isDisplayed(), "Element is not visible");
	}
	
	public String quoteNum() {
		return driver.findElement(By.id("readonly_1_quoteNumber_quote")).getText();
	    }
	
}
