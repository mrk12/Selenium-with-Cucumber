package com.util;

public interface Setup {

	
	String CHROME_KEY="webdriver.chrome.driver";
	String CHROME_PATH="src\\test\\resources\\Config\\chromedriver.exe";
	
	//String AUTOMATION_URL="https://gepw--pwtest.lightning.force.com/lightning/page/home";
	String AUTOMATION_URL="https://geren--renuat.lightning.force.com/";
	String username_TM ="502118030";
	String pwd_TM ="Trainer13SFDC";
	String username_AEM ="502208922";
	String pwd_AEM ="Trainer24SFDC";
	String username_AE ="502198360";
	String pwd_AE ="Trainer25SFDC";
	String quote_No="1253308-193844";
	String quoteName="dfds";
	String group_Name="testing";
	String group_Desc="Testing Desc";
	String username ="502576506";
	String pwd ="Sightforce@12GE";
	
}