package com.util;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.pages.AEPage;
import com.pages.HomePage;
import com.pages.LoginPage;
import com.pages.QuotePage;

public class TestBase implements Setup {

	WebDriver driver=null;
	
	public WebDriver initilizeDriver() {
		 ChromeOptions ops = new ChromeOptions();
        ops.addArguments("--disable-notifications");
		 System.setProperty(CHROME_KEY, CHROME_PATH);
		 driver=new ChromeDriver(ops);
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 return driver;
	}
	
	
	public LoginPage enterURL(String url) {
		driver.get(url);
		return new LoginPage(driver);
	}
	
	
	System properties = null;
	public String getReportConfigPath(){
		 
		String reportConfigPath = properties.getProperty("../../../../AutomationUseCase/extent-config.xml");
		 if(reportConfigPath!= null) return reportConfigPath;
		 else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath"); 
		}
	
	public QuotePage quotePage() {
		return new QuotePage(driver);
	}
	
	public AEPage aepage() {
		return new AEPage(driver);
	}
	
	public HomePage homepage() {
		return new HomePage(driver);
	}
}
