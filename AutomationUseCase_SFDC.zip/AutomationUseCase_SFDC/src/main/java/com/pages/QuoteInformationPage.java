package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.objrepo.QuoteInformation;
import com.util.WebDriverUtils;

import junit.framework.Assert;

public class QuoteInformationPage extends WebDriverUtils implements QuoteInformation{
WebDriver driver;
	public QuoteInformationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void selectEngineeredSolutions() throws InterruptedException {
		selectValueFromDropDown(oppoCategory, "Engineered Solutions");
		Thread.sleep(3000);
	}
	public void selectRepairs() throws InterruptedException {
		selectValueFromDropDown(oppoCategory, "Repairs");
		Thread.sleep(3000);
	}
	
	public void selectQuoteType() {
		selectValueFromDropDown(quoteType, "gasAEQuote");
	}
	public void selectPraposalType() {
		selectValueFromDropDown(proposalType, "Firm Fixed");
	}
	
	public void enterProposalTile() throws InterruptedException {
		Thread.sleep(3000);
		enterText(proposalTitle, "Test Proposal");
	}
 
	public void switchToFrame() throws InterruptedException {
		Thread.sleep(3000);
		selectFrame(grandParentFrame);
		new WebDriverWait(driver,30).until(ExpectedConditions.invisibilityOfElementLocated(oracleCPQLoader));
		Thread.sleep(3000);
		selectFrame(parentFrame);
		selectFrame(childFrame);
	}
	
	public void clickOnSaveButton() {
		clickUsingJavaScript(saveButton);
	}
	
	@SuppressWarnings("deprecation")
	public void verifyQuoteStatus() {		
		Assert.assertEquals("pendingCMSubmission_process", getlabelText(quoteStatusLabel));
		System.out.println("Status verified after Quote information filled");
	}
	
	@SuppressWarnings("deprecation")
	public void verifyQuoteStatusAfterSendRequest() {		
		Assert.assertEquals("awaitingAEMApproval", getlabelText(quoteStatusLabel));
		System.out.println("Status verified after request sent");
	}
	
	public void sendRequestToAEM() throws InterruptedException {
		Thread.sleep(10000);
		verifyQuoteStatus();
		quoteNum=quoteNum();
		clickUsingJavaScript(commercialMangr);
		Thread.sleep(2000);
		enterText(enggScope, "Please Approve");
		clickUsingJavaScript(requestDueDateButton);
		clickUsingJavaScript(today);
		clickUsingJavaScript(submitToAEMBtn);
		Thread.sleep(2000);
		enterText(comments, "Need to approve");
		clickUsingJavaScript(commSubmitBtn);
		Thread.sleep(5000);
		verifyQuoteStatusAfterSendRequest();
	}
	
	public void clickOnApplicationEngineerTab() {
		clickUsingJavaScript(appEngineer);
	}
	
	
	
	public void selectTRSPlanStatus() {
		selectValueFromDropDown(transPlanStatus, "Current location compliance not evaluated");
	}

	public void selectMaterialRequiredDropdown() throws InterruptedException {
		
		selectValueFromDropDown(materialReqDropdwn, "No");
	}
	
	public void selectSeamConditionDropdown() throws InterruptedException {
		
		selectValueFromDropDown(seamCondition, "No");
	}
	
	public void selectExceptionsToBidSpecDropdown() throws InterruptedException {
		
		selectValueFromDropDown(exceptionToBidSpecDrdwn, "No");
	}
	
	public void chooseTechnicalRiskcheckBox() throws InterruptedException {
		Thread.sleep(3000);
		clickUsingJavaScript(createTRAcheckBox);
	}
	
	public void submitButton() throws InterruptedException {
		clickUsingJavaScript(submitBUtton);
		Thread.sleep(1000);
		enterText(comments, "Need to approve");
		clickUsingJavaScript(commSubmitBtn);
		Thread.sleep(5000);
	}
	
	
	public void clickOnBOmUploadTab() throws InterruptedException {
		Thread.sleep(3000);
		clickUsingJavaScript(bomUploadTab);
	}
	
	public void clickOnRemoveCheckBox() {
		Boolean status = driver.findElement(removeFileCheckbox).isDisplayed();
		if(status == true) {
			clickUsingJavaScript(removeFileCheckbox);
		}
	}
	
	public void uploadFile() throws InterruptedException {		
		//clickUsingActions(bomUploadBrowseBtn);
		//clickUsingJavaScript(bomUploadBrowseBtn);
		//clickUsingXYCoordinates(bomUploadBrowseBtn, 628, 482);

//new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(bomUploadBrowseBtn)).click();
		Thread.sleep(6000);
		driver.manage().window().maximize();
		//click(bomUploadBrowseBtn);
		//Thread.sleep(6000);
		//enterText(bomUploadBrowseBtn, ".//src//test//resources//Config//gepowerwatersample.csv");
		/*WebElement element = driver.findElement(bomUploadBrowseBtn);
        JavascriptExecutor js =(JavascriptExecutor)driver;
        js.executeScript("window.scrollTo(0, "+element.getLocation().x+")");
        element.click();*/
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = driver.findElement(bomUploadBrowseBtn);


	       wait.until(ExpectedConditions.elementToBeClickable(element));
		/*Actions action = new Actions(driver);
		WebElement element = driver.findElement(bomUploadBrowseBtn);
		action.moveToElement(element).build().perform();
		Thread.sleep(1000);
		action.doubleClick();
		Thread.sleep(3000);*/
		/*WebElement element = driver.findElement(bomUploadBrowseBtn);
		JavascriptExecutor jse2 = (JavascriptExecutor)driver;
		jse2.executeScript("arguments[0].scrollIntoView()", element); 
		Thread.sleep(5000);*/
		
	}
	
	public void switchToFrameForAE() throws InterruptedException {
		Thread.sleep(3000);
		selectFrame(ggrandParentFrame);
		new WebDriverWait(driver,30).until(ExpectedConditions.invisibilityOfElementLocated(oracleCPQLoader));
		Thread.sleep(3000);
		selectFrame(parentFrame);
		selectFrame(childFrame);
	}
	
	
	
	
}
