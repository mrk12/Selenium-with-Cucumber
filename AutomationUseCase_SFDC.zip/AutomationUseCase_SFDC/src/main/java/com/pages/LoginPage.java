package com.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.objrepo.HomePageProp;
import com.objrepo.LoginPageProperties;
import com.util.WebDriverUtils;

public class LoginPage extends WebDriverUtils implements LoginPageProperties, HomePageProp {

	WebDriver driver; // Instance

	public LoginPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public void ssoUserName(String username) {
		enterText(SIGNIN_USERNAME, username);
	}

	public void ssoPwd(String pwd) {
		enterText(SIGNIN_PASSWORD, pwd);
	}

	public void loginSubmitBtn() {
		click(SIGNIN_SUBMITBUTTON);
		System.out.println("User able to navigate into Home page");
	}

	public boolean verifyHomeTextIsPresent() {
		if(isElementPresent(SFDC_MORE))
			return true;
		else
			return false;
		
	}

	public void clickOnAppLauncherIcon() {
		System.out.println("invoke the method");
		click(appLaunchButton);
	}
	
	public void closeWindow() {		
		driver.quit();
		System.out.println("Close the window");
	}
	//SFDC
	public void clickOnMoreOption() throws InterruptedException {
		System.out.println("invoke the method");
		clickUsingJavaScript(SFDC_MORE);
		Thread.sleep(2000);
	}
	public void clickOnMoreReportOption() throws InterruptedException {
		System.out.println("invoke the method");
		clickUsingJavaScript(SFDC_More_Report);
		Thread.sleep(4000);
	}
	
	public void clickOnNewReport() throws InterruptedException {
		System.out.println("Clicked on New Sales force Button");
		Thread.sleep(3000);
		clickUsingJavaScript(New_Report_SalesForce);
		Thread.sleep(4000);
		
	}
	public void switchToAccountsFrame() throws InterruptedException {
		Thread.sleep(2000);
		List<WebElement> iframes = driver.findElements(By.xpath("//iframe"));
        System.out.println(iframes.size());
        // you can reach each frame on your site
        for (WebElement iframe : iframes) {
            // switch to every frame
            driver.switchTo().frame(iframe);
           driver.findElement(By.xpath("//*[@id='quickFindInput']")).click();
        }
		//clickUsingJavaScript(CreateNewReport_SearchFld);
		Thread.sleep(2000);
		enterText(CreateNewReport_SearchFld, "Accounts");
		Thread.sleep(1000);
		clickUsingJavaScript(ACCOUNTS_OPTION);
		Thread.sleep(1000);
		clickUsingJavaScript(ACCOUNTS_CREATEBTN);
		Thread.sleep(1000);
	}
	public void switchToAccountsSecondFrame() throws InterruptedException {
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(7000);
		driver.switchTo().defaultContent();
		List<WebElement> iframes = driver.findElements(By.xpath("//iframe"));
        System.out.println(iframes.size());
        // you can reach each frame on your site
        for (WebElement iframe : iframes) {
            // switch to every frame
            driver.switchTo().frame(iframe);
           driver.findElement(By.xpath("//*[@id='quickFindInput']")).click();
        }
		//clickUsingJavaScript(CreateNewReport_SearchFld);
		Thread.sleep(2000);
		enterText(CreateNewReport_SearchFld, "Accounts");
		Thread.sleep(1000);
		clickUsingJavaScript(ACCOUNTS_OPTION);
		Thread.sleep(1000);
		clickUsingJavaScript(ACCOUNTS_CREATEBTN);
		Thread.sleep(1000);
	}
	
	public void clickOnAddBtn() throws InterruptedException {
		//System.out.println("invoke the method");
		clickUsingJavaScript(SHOW_DROPDOWN);
		Thread.sleep(2000);
		clickUsingJavaScript(SHOW_DROPDOWN_ALLACCOUNTS);
		Thread.sleep(2000);
		clickUsingJavaScript(RANGE_DROPDOWN);
		Thread.sleep(2000);
		clickUsingJavaScript(RANGE_DROPDOWN_ALLTIME);
		Thread.sleep(2000);
		clickUsingJavaScript(SFDC_ADDBtn);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		//clear(ACCOUNTOWNER_FLD);
		//Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLDClear);
		Thread.sleep(1000);
		enterText(ACCOUNTOWNER_FLDClear, "KYC Risk Level");
		Thread.sleep(1000);		
		clickUsingJavaScript(ACCOUNTOWNER_KeyRiskLevelTxtEnter);
		//Thread.sleep(3000);
		enterText(ACCOUNTOWNER_KEYTXT, "Standard & Heightened Customer Due Diligence");
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_OKBTN);
		Thread.sleep(7000);
	}
	
	public void clickOnSaveReport() throws InterruptedException {
		//System.out.println("invoke the method");
		isElementPresent(CreatedAccount_Row1);
		Thread.sleep(4000);
		clickUsingJavaScript(CreatedAccount_SaveBtn);
		Thread.sleep(2000);
		enterText(CreatedAccount_SaveReportTxt, "TC_45");
		Thread.sleep(2000);
		clickUsingJavaScript(SaveReportTxt_SaveBtn);
		Thread.sleep(8000);
	}
	public void clickOnRunReportsBtn() throws InterruptedException {
		Thread.sleep(4000);
		driver.switchTo().defaultContent();
	    driver.switchTo().frame(1);
            driver.findElement(By.xpath("//td[@class='x-toolbar-cell']/table[@id='runReportBtn']/descendant::button")).click();
            Thread.sleep(7000);
            
	}
	
	public void clickOnReportsTab() throws InterruptedException {
		System.out.println("Navigates to Reports Page");
		clickUsingJavaScript(Reports_Tab);
		Thread.sleep(5000);
	}
	
	public void clickOnSecondAddBtn() throws InterruptedException {
		//System.out.println("invoke the method");
		clickUsingJavaScript(SHOW_DROPDOWN);
		Thread.sleep(3000);
		clickUsingJavaScript(SHOW_DROPDOWN_ALLACCOUNTS);
		Thread.sleep(2000);
		clickUsingJavaScript(RANGE_DROPDOWN);
		Thread.sleep(2000);
		clickUsingJavaScript(RANGE_DROPDOWN_ALLTIME);
		Thread.sleep(2000);
		clickUsingJavaScript(SFDC_ADDBtn);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		//clear(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLDClear);
		Thread.sleep(2000);
		enterText(ACCOUNTOWNER_FLDClear, "KYP Consortium Risk Level");
		Thread.sleep(2000);		
		clickUsingJavaScript(ACCOUNTOWNER_KeyRiskLevelTxtEnter);
		Thread.sleep(2000);
		enterText(ACCOUNTOWNER_KEYTXT, "Heightened Intermediary Due Diligence");
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_OKBTN);
		Thread.sleep(4000);
		clickUsingJavaScript(SFDC_ADDBtn);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		//clear(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLDClear);
		Thread.sleep(2000);
		enterText(ACCOUNTOWNER_FLDClear, "APPROVAL STATUS FOR PARTNER");
		Thread.sleep(2000);		
		clickUsingJavaScript(ACCOUNTOWNER_KeyRiskLevelTxtEnter);
		Thread.sleep(3000);
		clickUsingJavaScript(ADD_EqualsDropDown);
		Thread.sleep(2000);
		clickUsingJavaScript(ADD_ContainsTxt);
		Thread.sleep(2000);
		enterText(ACCOUNTOWNER_KEYTXT, "Approvedpartner");
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_OKBTN);
		Thread.sleep(7000);
	}
	
	public void clickOnThirdAddBtn() throws InterruptedException {
		//System.out.println("invoke the method");
		clickUsingJavaScript(SHOW_DROPDOWN);
		Thread.sleep(3000);
		clickUsingJavaScript(SHOW_DROPDOWN_ALLACCOUNTS);
		Thread.sleep(2000);
		clickUsingJavaScript(RANGE_DROPDOWN);
		Thread.sleep(2000);
		clickUsingJavaScript(RANGE_DROPDOWN_ALLTIME);
		Thread.sleep(2000);
		clickUsingJavaScript(SFDC_ADDBtn);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		//clear(ACCOUNTOWNER_FLD);
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_FLDClear);
		Thread.sleep(2000);
		enterText(ACCOUNTOWNER_FLDClear, "KYC Risk Level");
		Thread.sleep(2000);		
		clickUsingJavaScript(ACCOUNTOWNER_KeyRiskLevelTxtEnter);
		Thread.sleep(2000);		
		clickUsingJavaScript(ADD_EqualsDropDown);
		Thread.sleep(1000);
		clickUsingJavaScript(ADD_NotEqualTxt);
		Thread.sleep(2000);
		enterText(ACCOUNTOWNER_KEYTXT, "Standard & Heightened Customer Due Diligence");
		Thread.sleep(2000);
		clickUsingJavaScript(ACCOUNTOWNER_OKBTN);
		Thread.sleep(7000);
	}
	public void newTabCreation() throws InterruptedException {
		System.out.println("Clicked on New Sales force Button");
		Thread.sleep(3000);
		driver.findElement(SFDC_More_Report).sendKeys(Keys.CONTROL+"t");
		Thread.sleep(4000);
		
	}
	
	public void clickOnOpportunityTab() throws InterruptedException {
		System.out.println("invoke the method");
		Thread.sleep(3000);
		clickUsingJavaScript(OpportunityTab);
		Thread.sleep(3000);
		
	}
	
	public void opportunityName() throws InterruptedException {
		Thread.sleep(3000);
		clickUsingJavaScript(OppNew);
		Thread.sleep(3000);
		clickUsingJavaScript(Next);
		Thread.sleep(3000);
		enterText(opportunityname, "testPOC");
		Thread.sleep(3000);
		enterText(accountname, "test");
		Thread.sleep(3000);
		clickUsingJavaScript(accountdropdown);
		Thread.sleep(3000);
		enterText(endusername, "test");
		Thread.sleep(3000);
		clickUsingJavaScript(enduserdropdown);
		Thread.sleep(3000);
		
	}
	
	public void date() throws InterruptedException {

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();	
	    cal.add(Calendar.DAY_OF_MONTH, 1);  	
		String newDate = sdf.format(cal.getTime()); 
		System.out.println(newDate);
		enterText(expecteddate, newDate);
		Thread.sleep(3000);
		enterText(planneddate, newDate);
		Thread.sleep(3000);
		clickUsingJavaScript(sales);
		Thread.sleep(3000);
		clickUsingJavaScript(salesoption);
		Thread.sleep(3000);
		clickUsingJavaScript(install);
		Thread.sleep(3000);
		clickUsingJavaScript(installdropdown);
		Thread.sleep(3000);
		clickUsingJavaScript(stage);
		Thread.sleep(3000);
		clickUsingJavaScript(stagedropdown);
		Thread.sleep(3000);
		clickUsingJavaScript(save);
	}
	
	public void newkeyplayer() throws InterruptedException {

		Thread.sleep(3000);
		clickUsingJavaScript(keyplayer);
		Thread.sleep(3000);
		clickUsingJavaScript(newkey);
		Thread.sleep(3000);
		enterText(account, "test");
		Thread.sleep(3000);
		clickUsingJavaScript(accountdrop);
		Thread.sleep(3000);
		clickUsingJavaScript(keyrole);
		Thread.sleep(3000);
		clickUsingJavaScript(arrowbutton);
		Thread.sleep(3000);
		clickUsingJavaScript(savekey);
	}
	
	public void opportunity() throws InterruptedException {

		Thread.sleep(3000);
		clickUsingJavaScript(opportunity);
	}
	public void newriskmodule() throws InterruptedException {

		Thread.sleep(3000);
		clickUsingJavaScript(riskmodule);
		Thread.sleep(3000);
		clickUsingJavaScript(newrisk);
		Thread.sleep(3000);
		clickUsingJavaScript(select);
		Thread.sleep(3000);
		clickUsingJavaScript(savekey);
	}
	
	public void newmeeting() throws InterruptedException {

		Thread.sleep(3000);
		clickUsingJavaScript(meetings);
		Thread.sleep(3000);
		clickUsingJavaScript(newmeeting);
		Thread.sleep(3000);
		clickUsingJavaScript(type);
		Thread.sleep(3000);
		clickUsingJavaScript(typedropdown1);
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();	
	    cal.add(Calendar.DAY_OF_MONTH, 1);  	
		String newDate = sdf.format(cal.getTime()); 
		System.out.println(newDate);
		enterText(meetingdate, newDate);
		Thread.sleep(3000);
		clickUsingJavaScript(savekey);
	}
}
