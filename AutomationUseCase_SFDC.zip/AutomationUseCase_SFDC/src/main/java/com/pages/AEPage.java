package com.pages;

import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.objrepo.AEPageProperties;
import com.objrepo.QuotePageProperties;

import com.util.Setup;
import com.util.WebDriverUtils;

public class AEPage extends WebDriverUtils implements AEPageProperties,QuotePageProperties{


	WebDriver driver; // Instance
	String generatedURL;
	String proposalPageURL;
	public AEPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public void clickOnAETab() throws InterruptedException {
		staticWait(1);
		//clickUsingJavaScript(aeTab);
		clickUsingJavaScript(aeTab);
		staticWait(1);
	}
	
	public void selectLegacyTab() {
		clickUsingJavaScript(LegacyTab);
		staticWait(1);
	}
	
	public void clickGenerateProposal() {
		clickUsingJavaScript(generateProposalBtn);
		staticWait(1);
	}

	
	public void clickOnLegacyTech() {
		clickUsingJavaScript(legacyTechProposal);
		staticWait(1);
	}
	
	public void verifyTemplateDisplay(String quoteNumber) {
		staticWait(2);
		String fileName=driver.findElement(updatedEngTempField).getText();
		System.out.println(fileName);
		if(fileName.contains("-Rev1.doc") && fileName.contains(quoteNumber)) {
			assertTrue(true);
		}else {
			assertTrue(false);
		}
		staticWait(1);
	}
	
	public void clickOnCustomerProposaltab() {
		staticWait(1);
		clickUsingJavaScript(customerProposaltab);
		staticWait(1);
	}
	
	public void enterGroupName(String text) {
		enterText(groupName, text);
	}
	
	public void enterGroupDesc(String text) {
		enterText(groupDesc, text);
	}
	
	public void clickOnPublishNow() {
		new WebDriverWait(driver, 30).until(ExpectedConditions.invisibilityOfElementLocated(loadingIcon));
		clickUsingJavaScript(publishBtn);
		proposalPageURL=driver.getCurrentUrl();
		System.out.println(proposalPageURL);
		new WebDriverWait(driver, 30).until(ExpectedConditions.invisibilityOfElementLocated(publishingIcon));
	}
	
	public void clickOnDownload() {
		staticWait(1);
		clickUsingJavaScript(Download);
	}
	
	public void downloadAsPDF() {
		staticWait(1);
		clickUsingJavaScript(pdfBtn);
	}
	
	public void openNow() {
		staticWait(1);
		clickUsingJavaScript(openNowURL);
	}
	
	public String getTitle() {
		return driver.getTitle();
	}
	
	public void verifyProposalURL() {
		staticWait(1);
		generatedURL=driver.findElement(currentProposalURL).getText();
		System.out.println(generatedURL);
		String arr[]=generatedURL.split("#");
		if(proposalPageURL.contains(arr[0])) {
			assertTrue(true);
		}else {
			assertTrue(false);
		}
	}
	
	public void switchWindow() {
		staticWait(1);
		String Parent=driver.getWindowHandle();
		Set<String> childWins=driver.getWindowHandles();
		for(String childWin:childWins) {
			if(!Parent.equals(childWin)) {
				driver.switchTo().window(childWin);
			}
		}
	}
	
	public void clickOnSave() {
		clickUsingJavaScript(saveBtn);
		staticWait(10);
	}
	
	public void refreshWin() {
		driver.navigate().refresh();
	}
	
	public void clickRouteInternal() {
		staticWait(1);
		clickUsingJavaScript(routingAndInternalTab);
		staticWait(1);
	}
	
	public void clickSubmitTOAEM() {
		clickUsingJavaScript(aeSubmitBtn);
		staticWait(1);
	}
	
	public void enterTechnicltext() {
		enterText(techProposalTitle, "test");
		staticWait(1);
	}
	
	public void setMaterialReq() {
		selectValueFromDropDown(materialReqDropdwn, "No");
		staticWait(1);
	}
	
	public void setSMEDetails() {
		selectValueFromDropDown(seamCondition, "No");
		staticWait(1);
	}
	
	public void setExceptionBid() {
		selectValueFromDropDown(exceptionToBidSpecDrdwn, "No");
		staticWait(1);
	}
	
	public void setTrsPlan() {
		selectValueFromDropDown(transPlanStatus, "Current location compliance not evaluated");
		staticWait(1);
	}
	
	public void clickSubmitInPopup() {
		enterText(aemCommentsInSubmitWin, "Approve it to AEM");
		clickUsingJavaScript(submitBtnInPopup);
		staticWait(1);
	}
	
	public void setTags(){
		click(tagMenuDrdwn);
		staticWait(1);
	}
	
	public void bomtab(){
		clickUsingJavaScript(bomtab);
		staticWait(1);
		//click(browseBtn);
		staticWait(60);
		clickUsingJavaScript(saveBtn);
		staticWait(3);
	}
}
	
