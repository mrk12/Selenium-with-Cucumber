package com.pages;

import static org.junit.Assert.assertTrue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.objrepo.HomePageProperties;
import com.objrepo.QuotePageProperties;

import com.util.Setup;
import com.util.WebDriverUtils;

public class QuotePage extends WebDriverUtils implements QuotePageProperties,HomePageProperties{
WebDriver driver;
JavascriptExecutor js;
String quoteNo;
	public QuotePage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		js=(JavascriptExecutor)driver;
	}

	public void SearchForQuote(String quoteNo) {
		clickUsingJavaScript(searchQuote);
		staticWait(3);
		enterText(searchQuote, quoteNo);
		driver.findElement(searchQuote).sendKeys(Keys.ENTER);
		staticWait(10);
		isElementPresent(HomePageProperties.editQuote(quoteNo));
	}
	
	/*public void SearchForQuote(String quoteNo) {
		clickUsingJavaScript(searchQuote);
		staticWait(3);
		enterText(searchQuote, Setup.quote_No);
		driver.findElement(searchQuote).sendKeys(Keys.ENTER);
		staticWait(10);
		isElementPresent(HomePageProperties.editQuote(Setup.quote_No));
	}*/
	

	 
	 
	public void clickDropDownForOptions() {
		
		clickUsingJavaScript(HomePageProperties.editQuote(quoteNum));
		//clickUsingJavaScript(HomePageProperties.editQuote(Setup.quote_No));
		staticWait(3);
	}
	
	public void clickEdit() {
		clickUsingJavaScript(editOption);
	}
	
	public void waitForQuotePagetoLoad() throws TimeoutException {
		staticWait(5);
		try {
			selectFrame(mainFrame);
			new WebDriverWait(driver,30).until(ExpectedConditions.invisibilityOfElementLocated(oracleCPQLoader));
			staticWait(5);
			selectFrame(secondFrame);
			selectFrame(cpqContentFrame);
			if(driver.findElement(currentStepStatus).isDisplayed()) {
				assertTrue(true);
			}else {
				assertTrue(false);
			}
		}catch(Exception e) {
         //do nothing
		}
		
		
	}
	
	public void minimizeGITab() {
		staticWait(2);
		//clickUsingJavaScript(generalInfoCollapse);
		clickUsingJavaScript(generalInfoCollapse);
	}
	
	public void maximizeGITab() {
		staticWait(1);
		clickUsingJavaScript(expandGITab);
		staticWait(1);
	}
	
	public void clickOnAEM() {
		clickUsingJavaScript(aemTab);
		//clickUsingJavaScript(aemTab);
	}
	
	public void verifyAEMFields() {
		staticWait(2);
		displayAssertion(techClarificationMeeting);
		displayAssertion(mAndcScope);
		displayAssertion(aeQuoteStatus);
		displayAssertion(aeAgreedDueDate);
		displayAssertion(aeAssignedEmail);
		displayAssertion(aeAssignedList);
		displayAssertion(aeAssignedNameLabel);
		displayAssertion(aemComments);
		displayAssertion(aemReason);
		displayAssertion(approveBtn);
		displayAssertion(rejectBtn);
	}
	
	public void fillReqDetails(String techClarity,String date) {
		 enterText(techClarificationMeeting, techClarity);
		 clickUsingJavaScript(aeAssignedList);
		 staticWait(2);
		 List<WebElement> names=driver.findElements(aeName);
		 staticWait(2);
		 System.out.println(names.size()+" list size");
		 for(WebElement ae:names) {
			 js.executeScript("arguments[0].scrollIntoView(true);", ae);
			 String selectedAEName=ae.getText();
			 System.out.println(ae.getText());
			 if(selectedAEName.contains("PGS Application")) {
				 ae.click();
				 staticWait(1);
				 clickUsingJavaScript(aeAssignedList);
				 break;
			 }
		 }
		 enterText(aeAgreedDueDate, date);
		 
	}
	
	public void approveReq() {
		staticWait(2);
		clickUsingJavaScript(approveBtn);
		//clickUsingJavaScript(approveBtn);
	}
	
	public String getdate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date=new Date();
		Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, 3);
        Date updatedDate=c.getTime();
       return dateFormat.format(updatedDate);
	}
	
	public void validateQuoteStatus(String status) {
		String quoteStatus=driver.findElement(currentStepStatus).getText().trim();	
		Assert.assertEquals(quoteStatus, status);
	}
	
	public void navigateTo_BOMMgmt() {
		staticWait(1);
		clickUsingJavaScript(bomApprovalMgmtTab);
		displayAssertion(lateEngrngProposalHeader);
		displayAssertion(ReasonCodeDropdown);
		displayAssertion(reasonCodeComments);
		displayAssertion(revisionRejectionCmtsHeader);
		displayAssertion(reviseCommentsEditBox);
		displayAssertion(techComplexityDropdown);
		displayAssertion(revertBtn);
		displayAssertion(reverToAEHeader);
		displayAssertion(reasonCodesForRevertDropdown);
		displayAssertion(reviseReasonCommentsEditBox);
		displayAssertion(approveBtn);
		displayAssertion(rejectBtn);
	}
	
	public void fillApprovalReqDetails() {
		selectValueFromDropDown(techComplexityDropdown, "Complex Project");
		enterText(aemReason, "approving the tech details");
	}
	
	
}
