package com.pages;

import org.openqa.selenium.WebDriver;

import com.objrepo.CreateQuotePageProp;
import com.util.WebDriverUtils;

public class CreateQuotePage extends WebDriverUtils implements CreateQuotePageProp{
WebDriver driver;
	public CreateQuotePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void searchCloudSite() throws InterruptedException {
		selectFrame(frame);
		Thread.sleep(5000);
		clickUsingJavaScript(cloudSiteSearchIcon);
	}
	
	public void selectSite() {
		switchToWindow(1);
		selectFrame(resultsFrame);
		clickUsingJavaScript(siteId);
	}

	public QuoteInformationPage clickOnCreateQuoteButton() throws InterruptedException {
		//Thread.sleep(2000);
		switchToWindow(0);
		selectFrame(frame);
		Thread.sleep(3000);
		clickUsingJavaScript(createQuoteButton);
		driver.switchTo().defaultContent();
		return new QuoteInformationPage(driver);
	}
}
