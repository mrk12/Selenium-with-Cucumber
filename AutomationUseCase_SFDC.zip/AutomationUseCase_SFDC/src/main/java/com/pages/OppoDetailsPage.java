package com.pages;

import org.openqa.selenium.WebDriver;

import com.objrepo.CreateQuotePageProp;
import com.objrepo.OpportunityDetailsPageProp;
import com.util.WebDriverUtils;

public class OppoDetailsPage extends WebDriverUtils implements OpportunityDetailsPageProp{
WebDriver driver;
	public OppoDetailsPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void clickonOCPQ() {
		clickUsingJavaScript(OCPQ);
	}

	public CreateQuotePage clickOnNew() {
		clickUsingJavaScript(newButton);
		return new CreateQuotePage(driver);
	}
}
