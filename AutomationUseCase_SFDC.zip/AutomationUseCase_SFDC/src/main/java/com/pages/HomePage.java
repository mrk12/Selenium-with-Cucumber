package com.pages;

import javax.security.auth.login.AccountNotFoundException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.objrepo.HomePageProp;
import com.util.WebDriverUtils;

import junit.framework.Assert;

public class HomePage extends WebDriverUtils implements HomePageProp{

	WebDriver driver; 

	public HomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public void sendTextToSalesForceSearchBox() {
		enterText(serachBox, "SalesForce Name");
	}
	
	
	public AppLauncher clickOnAppLauncherIcon() throws InterruptedException {
		clickUsingJavaScript(appLaunchButton);
		return new AppLauncher(driver);
	}
	
	public QuoteInformationPage openCreatedQuote() throws InterruptedException {
		enterText(serachBox, "1472783-193807");
		//clickOnEnter(serachBox);		
		Thread.sleep(2000);
		clickUsingJavaScript(quoteId);
		Thread.sleep(5000);
		clickUsingJavaScript(editButton);
		return new QuoteInformationPage(driver);
	}
	
	public void clickOnOpportunities() throws InterruptedException{ 
		clickUsingJavaScript(opportunitiesTab);
	}
	
	public void clickOnNewBtn(){
		clickUsingJavaScript(newButton);
		System.out.println(" Clicked On new button");
	}
	
	public void enterOpportunityname(){
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(opportunityName));
		enterText(opportunityName, "test");
	}
	
	public void searchForproject(){
		clickUsingJavaScript(searchProject);
		//enterText(searchProject, "Test Automation");
		clickUsingJavaScript(searchProjectOption);
	}
	
	public void selectAccount() throws InterruptedException{
		clickUsingJavaScript(acountName);
		Thread.sleep(3000);
		driver.findElement(acountName).sendKeys("GENERAL ELECTRIC (SWITZERLAND) GMBH"); 
		Thread.sleep(3000);
		clickUsingJavaScript(acountNameThirdOption);
	}
	
	public void selectEndUSer() throws InterruptedException{
		clickUsingJavaScript(endUser);
		Thread.sleep(3000);
		driver.findElement(endUser).sendKeys("GENERAL ELECTRIC (SWITZERLAND) GMBH"); 
		Thread.sleep(3000);
		clickUsingJavaScript(endUserThirdOption);
	}
	
	public void selectfromInstallCountryDropdown(){
		clickUsingJavaScript(installCountry);
		clickUsingJavaScript(countryName);
	}
	
	public void selectFromStagedropdown(){
		clickUsingJavaScript(stageDropdwn);
		clickUsingJavaScript(stageOption);
	}
	
	public void selectProposalType(){
		clickUsingJavaScript(proposalType);
		clickUsingJavaScript(proposalTypeOption);
	}
	
	public void selectProjectScope(){
		clickUsingJavaScript(projectScope);
		clickUsingJavaScript(projectScopeOption);
	}
	
	public void selectTier3PL(){
		clickUsingJavaScript(tier3PL);
		clickUsingJavaScript(tier3PLOption);
	}
	
	public void selectExpectOrderDate() throws InterruptedException{
		Thread.sleep(2000);
		clickUsingJavaScript(expectOrderdate);
		clickUsingJavaScript(expectOrderToday);
	}
	
	public void selectEquityOrFinance() throws InterruptedException{
		Thread.sleep(3000);
		clickUsingJavaScript(equityOrFinance);
		clickUsingJavaScript(equityOrFinanceOption);
	}
	
	public void clickOnSaveButton() throws InterruptedException{
		Thread.sleep(3000);
		clickUsingJavaScript(savebutton);
	}
	
	
	public void clickOnDealManagement(){
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(dealManagement));
		clickUsingJavaScript(dealManagement);
	}
	
	public void editOpportunity() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(openOpportunity));
		clickUsingJavaScript(openOpportunity);
		clickUsingJavaScript(oppEditButton);
		
	}
	



	
	
	

	public void validateFirstReport() throws InterruptedException{
		switchToFrame();
		Thread.sleep(1000);
		String firstOption =	driver.findElement(mt004Dropdown).getAttribute("selected");
		System.out.println("firstOption :"+ firstOption);
		Assert.assertEquals("true", firstOption);
	
	String secondOption = driver.findElement(mt006Text).getText();
	System.out.println("secondOption :"+ secondOption);
	Assert.assertEquals("Yes", secondOption);
	System.out.println("First Opportunity report validated");
	}
	
	//Third Opportunity
	
	public void ThirdEditTest() throws InterruptedException{
		clickUsingJavaScript(openOpp3);
		//Thread.sleep(10000);
		clickUsingJavaScript(OppurnityEditButton);
		//Thread.sleep(10000);
		clickUsingJavaScript(ACCOUNTNAMECancelButton);
		//Thread.sleep(10000);
		clickUsingJavaScript(acountName);
		//Thread.sleep(1000);
		driver.findElement(acountName).sendKeys("FIRST GEN ECOPOWER SOLUTIONS, INC"); 
		Thread.sleep(2000);
		clickUsingJavaScript(acountNameThird3Option);
		//Thread.sleep(10000);
		clickUsingJavaScript(ENDUSERCANCELButton);
		//Thread.sleep(10000);
		clickUsingJavaScript(endUser);
		Thread.sleep(1000);
		driver.findElement(endUser).sendKeys("FIRST GEN ECOPOWER SOLUTIONS, INC"); 
		Thread.sleep(1000);
		clickUsingJavaScript(endUserThird3Option);
		//Thread.sleep(1000);
		clickUsingJavaScript(savebutton);
		Thread.sleep(3000);
		
	}
	
	// New Peace of code

		public void switchToFrame() throws InterruptedException{
			Thread.sleep(3000);
			selectFrame(riskMangeFrame);
		}
		
			
		public void navigateToOpportunity(){
			
			clickUsingJavaScript(navigateToOpportunitylink);
		}
		
		public void clickOnKeyPlayers(){
			clickUsingJavaScript(keyPlayers);
		}
		
		public void clickOnNewButton(){
			clickUsingJavaScript(keyPlayNewBtn);
		}
		
		public void chooseSecondPreCondition(){
			clickUsingJavaScript(acountNamee);
			driver.findElement(acountName).sendKeys("SINOHYDRO CORPORATION LIMITED");
			clickUsingJavaScript(acountNameOptionn);
		}
		
		public void chooseKeyRole(){
			clickUsingJavaScript(keyRoleOption);
			clickUsingJavaScript(moveButton);
		}
		
		public void openOpportunity(){
			clickUsingJavaScript(openOpp);
		}
		
		public void validateSecondReport() throws InterruptedException{
			driver.navigate().refresh();
			Thread.sleep(5000);
			switchToFrame();
			Thread.sleep(1000);
		String firstOption =	driver.findElement(mt004Dropdown).getAttribute("selected");
		System.out.println("firstOption :"+ firstOption);
		Assert.assertEquals("true", firstOption);
		
		String secondOption = driver.findElement(mt006Text).getText();
		System.out.println("secondOption :"+ secondOption);
		Assert.assertEquals("No", secondOption);
		System.out.println("second Opportunity report validated");
		}
		
		public void validateThirdReport() throws InterruptedException{
			driver.navigate().refresh();
			Thread.sleep(5000);
			switchToFrame();
			Thread.sleep(1000);
		String firstOption =	driver.findElement(mt004Dropdown3).getAttribute("selected");
		System.out.println("firstOption :"+ firstOption);
		Assert.assertEquals("true", firstOption);
		
		String secondOption = driver.findElement(mt006Text).getText();
		System.out.println("secondOption :"+ secondOption);
		Assert.assertEquals("No", secondOption);
		System.out.println("Third Opportunity report validated");
		}
		
		public void clilckOnReverseDealMngmnt(){
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(dealMngmnt));
			clickUsingJavaScript(dealMngmnt);
		}
		public void clilckOnReverseDealMngmnt1(){
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(dealMangnt3));
			clickUsingJavaScript(dealMangnt3);
		}
		
		public void selectTermsConditionsdropdwon() throws InterruptedException{
			Thread.sleep(3000);
			clickUsingJavaScript(termsConditions);
			clickUsingJavaScript(termsConditionsOption);
			
		}
		
		public void selectOnshoreOffshore(){
			clickUsingJavaScript(onshoreOROffshoreDropdown);
			clickUsingJavaScript(onshoreOROffshoreDropdownOptionNo);
		}
		
		public void clickOnCancel() throws InterruptedException{
			Thread.sleep(5000);
			clickUsingJavaScript(By.xpath("//button[@title='Cancel']"));
		}
		public void clickOnDadshBoradTab() throws InterruptedException{
			clickUsingJavaScript(dashboard);
		}
		
	public void clickOnMasterTerms() throws InterruptedException{
			clickUsingJavaScript(masterTerms);
			System.out.println("clicked on master Terms");
			Thread.sleep(10000);
		}
	
	
}
