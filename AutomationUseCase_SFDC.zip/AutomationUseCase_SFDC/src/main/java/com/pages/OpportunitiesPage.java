package com.pages;

import org.openqa.selenium.WebDriver;

import com.objrepo.OpportunitiesPageprop;
import com.util.WebDriverUtils;

public class OpportunitiesPage extends WebDriverUtils implements OpportunitiesPageprop{
WebDriver driver;
	public OpportunitiesPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public OppoDetailsPage selectOpportunity() {
		clickUsingJavaScript(opportunityName);
		return new OppoDetailsPage(driver);
	}
	
}
