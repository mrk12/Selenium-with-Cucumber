package com.pages;

import org.openqa.selenium.WebDriver;

import com.objrepo.AppLauncherProp;
import com.util.WebDriverUtils;


public class AppLauncher extends WebDriverUtils implements AppLauncherProp{
WebDriver driver;
	public AppLauncher(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public OpportunitiesPage clickOnOpportunities() {
		clickUsingJavaScript(opportunities);
		return new OpportunitiesPage(driver);
	}

}
