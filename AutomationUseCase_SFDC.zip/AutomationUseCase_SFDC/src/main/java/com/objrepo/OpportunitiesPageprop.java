package com.objrepo;

import org.openqa.selenium.By;

public interface OpportunitiesPageprop {

	By opportunityName = By.xpath("//a[@title='BM_Testing_ES_OCT17_test']");
	
}
