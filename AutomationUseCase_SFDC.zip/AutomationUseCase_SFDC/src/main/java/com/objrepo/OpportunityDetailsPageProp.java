package com.objrepo;

import org.openqa.selenium.By;

public interface OpportunityDetailsPageProp {
	By OCPQ = By.xpath("//a[@title='oCPQ']");
	By newButton = By.xpath("//*[@role='tabpanel']//a[@title='New']");
	
}
