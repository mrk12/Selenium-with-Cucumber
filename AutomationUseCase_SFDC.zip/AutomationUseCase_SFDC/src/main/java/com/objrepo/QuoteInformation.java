package com.objrepo;

import org.openqa.selenium.By;

public interface QuoteInformation {
	By grandParentFrame = By.xpath("(//iframe[@title='accessibility title'])[2]");
	By parentFrame = By.xpath("//iframe[@title='Canvas IFrame for application Oracle CPQ Cloud.']");
	By childFrame = By.xpath("//iframe[@title='Oracle CPQ Cloud']");
	By oracleCPQLoader= By.xpath("//span[text()='Loading Oracle CPQ Cloud...']");
	By oppoCategory = By.xpath("//div[@id='attr_wrapper_1_opportunityCategory_quote']//select[@name='opportunityCategory_quote']");
	By quoteType = By.cssSelector("select[name='quoteType_quote_ES']");
	By proposalType = By.cssSelector("select[name='proposalType_quote']");
	By proposalTitle = By.cssSelector("input[name='quoteDescription_quote']");
	By saveButton = By.cssSelector("a[id='save']");
	
	By commercialMangr = By.xpath("//span[contains(text(), 'Commercial Manager')]");
	By enggScope = By.xpath("//textarea[@id='engineeringScope_quote']");
	By requestDueDateButton = By.cssSelector("a#engCompleteDate-button");
	By today = By.cssSelector("button.calendar-settoday");
	By submitToAEMBtn = By.cssSelector("a#submit_to_aem");
	By comments = By.cssSelector("textarea#performer_comment");
	By commSubmitBtn = By.xpath("//div[@id='reasons_popup']//a[contains(text(), 'Submit')]");
	By quoteStatusLabel = By.cssSelector("span#readonly_1_currentStep");
	By quoteNumber = By.id("readonly_1_quoteNumber_quote");
	By ggrandParentFrame = By.xpath("//iframe[@title='accessibility title']");
	

	By appEngineer = By.xpath("(//span[contains(text(),'Application Engineer')])[5]");
	By techProposalTitle = By.cssSelector("input#technicalProposalTitle_ES");
	By materialReqDropdwn = By.cssSelector("select[name='SAEMPerfCond_es']");
	By seamCondition = By.cssSelector("select[name='materialRequired_es']");
	By transPlanStatus = By.cssSelector("select[name='TRSPlanStatus_es']");
	By exceptionToBidSpecDrdwn = By.cssSelector("select[name='exceptClarBid_es']");
	By techQuoteReftextField = By.cssSelector("textarea#techQuoteRef_es");
	By noteTotecManagerTextField = By.cssSelector("textarea#notesCMPM_es");
	By tagCodesSearchField = By.cssSelector("input#sourceBookCodesSearch");
	By frameSizeDrwn = By.cssSelector("select#frameSizeSmartBOM");
	By selectScopeDrdwn = By.cssSelector("input#sourceBookCodesSearch");
	By tagMenuDrdwn = By.cssSelector("select[name='sourcebookMenu_quote']");
	By createTRAcheckBox = By.cssSelector("input[name='createTRACase']");
	By submitBUtton = By.cssSelector("a#submit");
	
	By bomUploadTab = By.xpath("//span[contains(text(), 'BOM Upload')]");
	By removeFileCheckbox = By.cssSelector("input[name='_delete_excelUploadAttachment_quote']");
	By bomUploadBrowseBtn = By.xpath("//div[@id='field_wrapper_1_excelUploadAttachment_quote']//*[contains(text(), 'Browse...')]");
	
	
	
}
