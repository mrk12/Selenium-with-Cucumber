package com.objrepo;

import org.openqa.selenium.By;

public interface CreateQuotePageProp {
	By frame = By.xpath("//iframe[@title='accessibility title']");
	By cloudSiteSearchIcon = By.xpath("//a[@title='Oracle CPQ Cloud Site Lookup (New Window)']");
	By siteId = By.xpath("//*[contains(text(), 'SITE-000')]");
	By createQuoteButton = By.xpath("//input[@value='Create Quote']");
	By resultsFrame = By.xpath("//frame[@id='resultsFrame']");
	
}
