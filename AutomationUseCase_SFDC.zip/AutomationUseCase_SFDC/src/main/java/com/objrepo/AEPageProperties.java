package com.objrepo;

import org.openqa.selenium.By;

public interface AEPageProperties {

	By tagMenuDrdwn = By.xpath("//select[@name='sourcebookMenu_quote']/option[1]");
	By aeTab=By.xpath("//div[@class='panel collapsible panel-collapsed']/descendant::span[text()='Application Engineer']");
	By LegacyTab=By.xpath("//span[text()='Legacy Gas']");
	By generateProposalBtn=By.cssSelector("div#readonly_1_generateTBProposal_Gas_ES_quote a");
	By currentProposalURL=By.id("readonly_1_currentProposalgaslink_tb");
	By updatedEngTempField=By.cssSelector("span#_name_uploadEngineeringTemplate_File a");
	By browseBtn=By.id("browse...");
	By uploadBtn=By.id("_file_excelUploadAttachment_quote");
	By bomtab=By.xpath("//span[text()='BOM Upload']");
	By publishBtn=By.id("publish-doc");
	By Download=By.xpath("//a[@class='downloads btn primary']");
	By loadingIcon=By.xpath("//span[text()='Loading']");
	By publishingIcon=By.xpath("//span[text()='Publishing']");
    By pdfBtn=By.xpath("//a[text()='Adobe PDF']");	
    By legacyTechProposal=By.xpath("//span[text()='Legacy Tech Proposal']");
    By customerProposaltab=By.xpath("//div[@class='panel collapsible panel-collapsed']/descendant::span[text()='Customer Proposal']");
    By groupName=By.id("customGroup1Name_quote");
    By groupDesc=By.id("customGroup1Desc_quote");
    By openNowURL=By.xpath("//a[text()='Open Now']");
    By saveBtn=By.xpath("//*[@id='save']");
    By routingAndInternalTab=By.xpath("//span[text()='Routing and Internal Notes']");
    By aeSubmitBtn=By.id("submit");
    By aemCommentsInSubmitWin=By.id("performer_comment");
    By submitBtnInPopup=By.xpath("//div[@class='popup-footer']/descendant::a[text()='Submit']");
    By cancelBtnInPopup=By.xpath("//div[@class='popup-footer']/descendant::a[text()='Cancel ']");
    By techProposalTitle = By.cssSelector("input#technicalProposalTitle_ES");
	By materialReqDropdwn = By.cssSelector("select[name='SAEMPerfCond_es']");
	By seamCondition = By.cssSelector("select[name='materialRequired_es']");
	By transPlanStatus = By.cssSelector("select[name='TRSPlanStatus_es']");
	By exceptionToBidSpecDrdwn = By.cssSelector("select[name='exceptClarBid_es']");
	By techQuoteReftextField = By.cssSelector("textarea#techQuoteRef_es");
    By createTRAcheckBox = By.cssSelector("input[name='createTRACase']");
}
