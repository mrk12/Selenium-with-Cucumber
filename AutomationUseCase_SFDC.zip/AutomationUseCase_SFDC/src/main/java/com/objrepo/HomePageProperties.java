package com.objrepo;

import org.openqa.selenium.By;

public interface HomePageProperties {

	
	By appLaunchButton = By.xpath("//a[@title='Customer']");
	By menuButton= By.xpath("//button[@class='slds-button']");
    By searchQuote= By.xpath("//input[@title='Search Salesforce']");
    By quoteId = By.xpath("//ul[@class='lookup__list  visible']/li[2]");
	By editButton = By.cssSelector("a[title='Edit']"); //need to wat
    //By editQuote=By.xpath("//tr//a[@title='1472783-193718']/following::a[contains(@class,'rowActionsPlaceHolder')]");
    
    
    public static By editQuote(String quoteNo) {
    	return By.xpath("//tr//a[@title='"+quoteNo+"']/following::a[contains(@class,'rowActionsPlaceHolder')]");
    }
	By editOption=By.xpath("//div[contains(@class,'visible positioned')]/descendant::a[@title='Edit']");
}
