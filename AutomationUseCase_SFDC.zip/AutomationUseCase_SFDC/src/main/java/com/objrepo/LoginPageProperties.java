package com.objrepo;

import org.openqa.selenium.By;

public interface LoginPageProperties {

	
	By SIGNIN_USERNAME=By.name("username");
	By SIGNIN_PASSWORD=By.name("password"); 
	By SIGNIN_SUBMITBUTTON=By.name("submitFrm");
	//By CPQ_HOMEPAGE=By.xpath("//*[@class='slds-grid slds-has-flexi-truncate']//span[text()='Home']");

	By SFDC_MORE=By.xpath("//*[@class='slds-p-right_small']");
	By SFDC_More_Report=By.xpath("//*[@class='slds-truncate']/span[text()='Reports']");
	By New_Report_SalesForce =By.xpath("//*[@class='slds-truncate'][text()='New Report (Salesforce Classic)']");
	By CreateNewReport_SearchFld=By.xpath("//*[@id='quickFindInput']");
	By ACCOUNTS_OPTION=By.xpath("//*[@class='x-tree-node-anchor']/span[text()='Accounts']");
	By ACCOUNTS_Frame=By.xpath("//iframe[@class='isEdit reportsReportBuilder']");
	By ACCOUNTS_CREATEBTN=By.xpath("//*[@id='thePage:rtForm:createButton'][@value='Create']");
	By SHOW_DROPDOWN=By.xpath("//*[@id='ext-gen149']");
	By SHOW_DROPDOWN_ALLACCOUNTS=By.xpath("//*[@class='x-combo-list-item'][text()='All accounts']");
	By RANGE_DROPDOWN=By.xpath("//*[@id='ext-gen154']");
	By RANGE_DROPDOWN_ALLTIME=By.xpath("//*[@class='x-combo-list-item'][text()='All Time']");
	By SFDC_ADDBtn=By.xpath("//*[@class=' x-btn-text'][text()='Add']");
	By ACCOUNTOWNER_FLD=By.xpath("//*[@id='ext-gen696']");
	By ACCOUNTOWNER_FLDClear=By.xpath("//*[@id='col-ext-gen679']");	
	By ACCOUNTOWNER_KeyRiskLevelTxtEnter=By.xpath("//*[@id='ext-gen712']/div[2]");
	By ACCOUNTOWNER_KEYTXT=By.xpath("//*[@name='pv']");
	By ACCOUNTOWNER_OKBTN=By.xpath("//*[@id='ext-gen704']");
	By CreatedAccount_Row1=By.xpath("//*[@id='ext-gen708']");
	By CreatedAccount_SaveBtn=By.xpath("//*[@id='ext-gen53'][text()='Save']");
	By CreatedAccount_SaveReportTxt=By.xpath("//*[@id='saveReportDlg_reportNameField']");
	By SaveReportTxt_SaveBtn=By.xpath("//*[@id='dlgSaveReport']");
	By RunReportBtn=By.xpath("//*[@class=' x-btn-text run-report-btn-icon'][text()='Run Report']");
	
	
	By Reports_Tab=By.xpath("//*[@title='Reports']/span[text()='Reports']");
	By ADD_EqualsDropDown=By.xpath("//*[@id='ext-gen699']");
	By ADD_ContainsTxt=By.xpath("//*[@class='x-combo-list-inner']/div[text()='contains']");
	By ADD_NotEqualTxt=By.xpath("//*[@class='x-combo-list-inner']/div[text()='not equal to']");
	
	By OpportunityTab=By.xpath("//*[@class='slds-truncate'][text()='Opportunities']");
	By opportunity=By.xpath("(//table/tbody/tr/th/span/a)[1]");
	By OppNew=By.xpath("//*[@class='forceActionLink']");
	By Next=By.xpath("//button/span[@class=' label bBody'][contains(text(),'Next')]");
	By opportunityname=By.xpath("(//*[@class='uiInput uiInputText uiInput--default uiInput--input']/input)[1]");
	By accountname=By.xpath("(//*[@class='autocompleteWrapper slds-grow']/input)[2]");
	By accountdropdown=By.xpath("//*[@class='primaryLabel slds-truncate slds-lookup__result-text'][@title='ZZZ TEST TEST TEST']");
	By endusername=By.xpath("(//*[@class='autocompleteWrapper slds-grow']/input)[3]");
	By enduserdropdown=By.xpath("(//*[@class='primaryLabel slds-truncate slds-lookup__result-text'][@title='ZZZ TEST TEST TEST'])[2]");
	By expecteddate=By.xpath("(//*[@class='form-element']/input)[6]");
	By planneddate=By.xpath("(//*[@class='form-element']/input)[11]");
	By save=By.xpath("//button[@class='slds-button slds-button--neutral uiButton--brand uiButton forceActionButton']/span[contains(text(),'Save')]");
	By sales=By.xpath("(//a[@class='select'])[2]");
	By salesoption=By.xpath("(//a[@role='menuitemradio'][@title='Asia Pacific'])");
	By install=By.xpath("(//a[@class='select'])[3]");
	By installdropdown=By.xpath("(//a[@role='menuitemradio'][@title='AFGHANISTAN'])");	
	By stage=By.xpath("(//a[@class='select'])[1]");
	By stagedropdown=By.xpath("(//a[@role='menuitemradio'][@title='Prospect'])");
	By keyplayer=By.xpath("//div[contains(@class,'windowViewMode-normal')]//descendant::span[text()='Key Players']");
	By newkey=By.xpath("(//a[@class='forceActionLink']/div[@title='New'])[2]");
	By newmeeting=By.xpath("(//a[@class='forceActionLink']/div[@title='New'])[3]");
	By newrisk=By.xpath("(//a[@class='forceActionLink']/div[@title='New'])[4]");
	By account=By.xpath("(//div[@class='autocompleteWrapper slds-grow']/input)[2]");
	By accountdrop=By.xpath("//div[@class='primaryLabel slds-truncate slds-lookup__result-text'][@title='ZZZ TEST TEST TEST']");
	By keyrole=By.xpath("//div/ul/li[@class='slds-listbox__item']/div/span/span[@title='Prime Contractor']");
	By arrowbutton=By.xpath("(//button[@class='slds-button slds-button_icon slds-button_icon-container'])[1]");
	By riskmodule=By.xpath("//div[contains(@class,'windowViewMode-normal')]//descendant::span[text()='Risk Modules']");
	By select=By.xpath("//*[@class='slds-modal__footer slds-modal__footer_directional']/button[contains(text(),'Select')]");
	By meetings=By.xpath("//div[contains(@class,'windowViewMode-normal')]//descendant::span[text()='Meetings']");
	By type=By.xpath("(//div[@class='uiPopupTrigger']/div/div/a[@class='select'])[1]");
	By typedropdown1=By.xpath("//a[@role='menuitemradio'][@title='R0']");
	By typedropdown2=By.xpath("//a[@role='menuitemradio'][@title='R1']");
	By meetingdate=By.xpath("//div[@class='form-element']/input");
	By savekey=By.xpath("//button[@class='slds-button slds-button--neutral uiButton--brand uiButton forceActionButton']/span[contains(text(),'Save')]");
}
