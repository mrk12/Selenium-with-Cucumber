package com.objrepo;

import org.openqa.selenium.By;

public interface HomePageProp {
	
	By serachBox = By.cssSelector("input[title='Search Salesforce']");
	By appLaunchButton = By.xpath("//div[@class='slds-icon-waffle']");
	By customerTab = By.xpath("//a[@title='Customer']");
	By quoteId = By.xpath("//ul[@class='lookup__list  visible']/li[2]");
	By editButton = By.cssSelector("a[title='Edit']");
	
	
	
	
	
	By opportunitiesTab = By.xpath("//*[@title='Opportunities']/span[text()='Opportunities']");
	
	By newButton = By.xpath("(//*[@title='New'])[1]");
	
	By opportunityName = By.xpath("//span[contains(text(), 'Opportunity Name')]/parent::label/following-sibling::input");
	
	By searchProject = By.xpath("//input[@title='Search Projects']");
	By searchProjectOption = By.xpath("//input[@title='Search Projects']/parent::div/div/div[2]/ul/li[1]");
	
	By acountName = By.xpath("(//input[@title='Search Accounts'])[1]");
	By acountNameOption = By.xpath("//div[@title='GENERAL ELECTRIC (SWITZERLAND) GMBH']/ancestor::a");
	
	By endUser = By.xpath("(//input[@title='Search Accounts'])[2]");
	By endUserOption = By.xpath("(//div[@title='GENERAL ELECTRIC (SWITZERLAND) GMBH']/ancestor::a)[2]");
	
	
	By installCountry = By.xpath("//*[contains(text(), 'Install Country')]/ancestor::div[1]//following-sibling::div/div/div/div/a");
	By countryName = By.xpath("//a[@title='ALAND ISLANDS']");
	
	By primaryOpportunity = By.xpath("//*[contains(text(), 'Primary Opportunity')]/ancestor::div[1]/div/div/div/div/a");
	By primeOpportOption = By.xpath("//a[@title='Yes']");
	
	By stageDropdwn = By.xpath("//*[contains(text(), 'Stage')]/parent::span/following-sibling::div/div/div/div/a");
	By stageOption = By.xpath("//a[@title='Prospect']");
	
	By proposalType = By.xpath("//*[contains(text(), 'Proposal Type')]/ancestor::div[1]/div/div/div/div/a");
	By proposalTypeOption = By.xpath("//a[@title='Budgetary']");
	
	By projectScope = By.xpath("//*[contains(text(), 'Project Scope')]/parent::span//following-sibling::div/div/div/div/a");
	By projectScopeOption = By.xpath("//a[@title='Turnkey Self Implement-Combined Cycle']");
	
	By tier3PL = By.xpath("//span[contains(text(), 'Tier 3 P&L')]/parent::span/following-sibling::div/div/div/div/a");
	By tier3PLOption = By.xpath("//a[@title='Aero']");
	
	By expectOrderdate = By.xpath("//span[contains(text(), 'Expected Order Date')]/parent::label/following-sibling::div/input");
	By expectOrderToday = By.xpath("//span[contains(text(), 'Today')]/parent::td");
	
	By equityOrFinance = By.xpath("//span[contains(text(), 'Does oppty require equity or financing?')]/parent::span/following-sibling::div//a");
	By equityOrFinanceOption = By.xpath("//a[@title='No']");
	
	By savebutton = By.xpath("//button[@title='Save']");
	
	
	By dealManagement = By.xpath("//span[@title='Deal Management']");
	By openOpportunity = By.xpath("//a[@title='test-DM']");
	By oppEditButton = By.xpath("//div[@title='Edit']");
	By termsConditions = By.xpath("//span[contains(text(), 'Terms and Conditions')]/parent::span/following-sibling::div//a");
	By termsConditionsOption = By.xpath("//a[@title='GE Customized T&Cs']");
	
	By onshoreOROffshoreDropdown = By.xpath("//span[contains(text(), 'Is it a split contract Onshore/Offshore?')]/parent::span/following-sibling::div//a");
	By onshoreOROffshoreDropdownOptionNo = By.xpath("//a[@title='No']");
	
	By dashboard = By.xpath("//a[contains(text(), 'Dashboard')]");
	
	By masterTerms = By.xpath("//div[@title='Master Terms']/a");
	
	By mt004Dropdown = By.xpath("//span[contains(text(), 'MTO04')]/parent::td/following-sibling::td/span/select/option[2]");
	By mt004Dropdown3 = By.xpath("//span[contains(text(), 'MTO04')]/parent::td/following-sibling::td/span/select/option[3]");
	
	By mt006Text = By.xpath("//span[contains(text(), 'MTO06')]/parent::td/following-sibling::td/span[1]");
	
	By riskMangeFrame = By.xpath("//iframe[contains(@title, 'Risk Manager')]");
	
	By navigateToOpportunitylink = By.xpath("//label[contains(text(), 'Opportunity')]/following-sibling::span/a");
	By keyPlayers = By.xpath("//span[contains(text(), 'Key Players')]");
	By keyPlayNewBtn = By.xpath("//button[contains(text(), 'New')]");
	
	By acountNamee = By.xpath("(//input[@title='Search Accounts'])[1]");
	By acountNameOptionn = By.xpath("//div[@title='SINOHYDRO CORPORATION LIMITED']/ancestor::a");
	
	By keyRoleOption = By.xpath("//div[@data-value='Consortium with GE']");
	By moveButton = By.xpath("//button[@title='Move selection to Chosen']");
	
	By openOpp = By.xpath("(//span[contains(text(), 'Opportunity')]/parent::div/following-sibling::div/span//a)[2]");
	By dealMngmnt = By.xpath("(//span[@title='Deal Management']/parent::a)[4]");
	By dealMangnt3 = By.xpath("//*[@class='outputLookupContainer forceOutputLookupWithPreview']/a");
	By openOpp3 = By.xpath("(//*[@class='slds-size--1-of-2 slds-float--left']/div/span/a)[1]");
	
	/*By navigateToOpportunitylink = By.xpath("//label[contains(text(), 'Opportunity')]/following-sibling::span/a");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");
	By savebutton = By.xpath("//button[@title='Save']");*/
	//By endUserThirdOption = By.xpath("(//div[@title='GENERAL ELECTRIC (SWITZERLAND) GMBH']/ancestor::a)[2]");
	
	By OppurnityTestButton = By.xpath("//*[@id='brandBand_1']/div/div[1]/div[4]/div/div/div[2]/div/div[1]/div[2]/div[2]/div[1]/div/div/table/tbody/tr[1]/th/span/a");
	By OppurnityEditButton = By.xpath("//*[@class='slds-button slds-button--neutral slds-truncate']/a[@title='Edit']");
	By ACCOUNTNAMECancelButton = By.xpath("//*[@class='test-id__section-content slds-section__content section__content']/div/div[3]/div[1]/div/div/div/div/div/div[2]/div/ul/li[1]/a/a/span[1]");
	By ENDUSERCANCELButton = By.xpath("//*[@class='test-id__section-content slds-section__content section__content']/div/div[4]/div[1]/div/div/div/div/div/div[2]/div/ul/li[1]/a/a/span[1]");
	By acountNameThirdOption = By.xpath("//span[text()='Account Name']/ancestor::label/following-sibling::div/descendant::div[@title='GENERAL ELECTRIC (SWITZERLAND) GMBH']/ancestor::a");
	By endUserThirdOption = By.xpath("//span[text()='End User']/ancestor::label/following-sibling::div/descendant::div[@title='GENERAL ELECTRIC (SWITZERLAND) GMBH']/ancestor::a");
	
	By acountNameThird3Option = By.xpath("//span[text()='Account Name']/ancestor::label/following-sibling::div/descendant::div[@title='FIRST GEN ECOPOWER SOLUTIONS, INC']/ancestor::a");
	By endUserThird3Option = By.xpath("//span[text()='End User']/ancestor::label/following-sibling::div/descendant::div[@title='FIRST GEN ECOPOWER SOLUTIONS, INC']/ancestor::a");
}
