package com.objrepo;

import org.openqa.selenium.By;

public interface AppLauncherProp {
	

 By opportunities = By.xpath("//a[@title='Opportunities']");
 
 
}
