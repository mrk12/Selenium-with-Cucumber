package com.objrepo;

import org.openqa.selenium.By;

public interface QuotePageProperties {

	By oracleCPQLoader= By.xpath("//span[text()='Loading Oracle CPQ Cloud...']");
	By generalInfoCollapse=By.xpath("//span[text()='General Information']");
	By currentStepStatus=By.cssSelector("div#attr_wrapper_1_currentStep div div#readonly_1_currentStep span");
	By aemTab=By.xpath("//div[@class='panel collapsible panel-collapsed']/descendant::span[text()='Application Engineering Manager']");
    By mainFrame=By.xpath("//div[contains(@class,'windowViewMode-normal')]/descendant::iframe[@title='accessibility title']");
    By secondFrame=By.xpath("//iframe[contains(@title,'Canvas IFrame')]");
    By cpqContentFrame=By.cssSelector("iframe[title='Oracle CPQ Cloud']");
    By techClarificationMeeting=By.cssSelector("textarea#techClarificationMeetingNotes_quote");
    By mAndcScope=By.cssSelector("div#field_wrapper_1_mCScope_quote");
    By aeQuoteStatus=By.cssSelector("span#readonly_1_aEQuoteStatus");
    By aeAssignedNameLabel=By.cssSelector("div#attr_wrapper_1_aEAssigned");
    By aeAssignedName=By.cssSelector("span#readonly_1_aEAssigned");
    By aeAssignedList=By.cssSelector("div#field_wrapper_1_aEAssignedNamesList_HTML div#readonly_1_aEAssignedNamesList_HTML");
    By aeAssignedEmail=By.cssSelector("div#attr_wrapper_1_placeHolder1");
    By aeAgreedDueDate=By.cssSelector("div#field_wrapper_1_agreedEngDueDate input");
    By aemComments=By.cssSelector("textArea#aEMComments");
    By aemReason=By.cssSelector("div.form-approval-wrapper input");
    By approveBtn=By.xpath("//a[contains(@title,'Approve')]/img");
    By rejectBtn=By.xpath("//a[contains(@title,'Reject')]/img");
    By aeName=By.xpath("//select[@id='aEAssignedNamesList']/option");
    By bomApprovalMgmtTab=By.xpath("//span[text()='BOM Approval Management']");
    By lateEngrngProposalHeader=By.cssSelector("div#readonly_1_lateEngineeringProposal u");
    By ReasonCodeDropdown=By.name("lateProposalReasonCode_ES");
    By reasonCodeComments=By.id("lateProposalReasonComments_ES");
    By revisionRejectionCmtsHeader=By.cssSelector("div#readonly_1_rejectionRevisionComments u");
    By reviseCommentsEditBox=By.id("reviseComments");
    By techComplexityDropdown=By.name("typeOfFlow_quote");
    By revertBtn=By.name("revertAction");
    By reverToAEHeader=By.cssSelector("div#readonly_1_revertToAEReason u");
    By reasonCodesForRevertDropdown=By.name("reasonCodes_quote");
    By reviseReasonCommentsEditBox=By.id("reasonCodeComments_quote");
    By ReasonEditbox=By.cssSelector("div.form-approval-wrapper input");
    By expandGITab=By.xpath("//div[@class='panel collapsible panel-collapsed']/descendant::span[text()='General Information']");
    
    
    
}
