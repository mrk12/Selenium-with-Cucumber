package com.objrepo;

import org.openqa.selenium.By;

public interface PersonalInformationProperties {

	
	By FIRSTNAME_LOCATOR=By.id("firstname");
	By PASSWORD_LOCATOR=By.id("old_passwd");
	By SAVE_BUTTON=By.name("submitIdentity");
	
}
