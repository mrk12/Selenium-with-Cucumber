package com.objrepo;

import org.openqa.selenium.By;

public interface SigninPageProperties {

	
	By EMAIlADDRESS_LOCATOR=By.id("email_create");
	By CREATEACCOUNT_LOCATOR=By.id("SubmitCreate");
	By LOGIN_EMAILADDRESS=By.id("email");
	By LOGIN_PASSWORD=By.id("passwd");
	By LOGIN_BUTTON=By.id("SubmitLogin");
}
