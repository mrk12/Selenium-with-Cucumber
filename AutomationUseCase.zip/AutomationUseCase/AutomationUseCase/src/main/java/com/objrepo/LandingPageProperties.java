package com.objrepo;

import org.openqa.selenium.By;

public interface LandingPageProperties {

	
	By SIGNIN_LOCATOR=By.xpath("//a[@class='login']");
}
