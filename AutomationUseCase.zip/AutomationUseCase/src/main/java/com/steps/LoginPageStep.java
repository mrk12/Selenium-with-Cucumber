package com.steps;


import com.util.Setup;
import com.util.TestBase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStep{

	
	Steps steps;
	
	public LoginPageStep(Steps steps) {
		this.steps=steps;
	}
	
	@Given("^user launch browser$")
	public void user_launch_browser() {
		steps.testBase=new TestBase();
		steps.testBase.initilizeDriver();
	}
	
	@When("^user enter url$")
	public void enter_url() {
		steps.loginPage=steps.testBase.enterURL(Setup.AUTOMATION_URL);
	}
	@Then("^User able to enter valid Credentials$")
	public void enter_SSO() {
		
		steps.loginPage.ssoUserName(Setup.username);
		steps.loginPage.ssoPwd(Setup.pwd);
		steps.loginPage.loginSubmitBtn();
	}

	
	
	/*@And("^user click on signin link$")
	public void click_on_signin() {
		steps.signinPage=steps.loginPage.clickSignin();
	}*/
	
	
	
}
