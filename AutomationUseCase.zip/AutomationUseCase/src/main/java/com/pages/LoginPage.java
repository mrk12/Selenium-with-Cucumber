package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.objrepo.LoginPageProperties;
import com.util.WebDriverUtils;






public class LoginPage extends WebDriverUtils implements LoginPageProperties{

	WebDriver driver; //Instance 

	public LoginPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}123

	public void ssoUserName(String username) {
		enterText(SIGNIN_USERNAME, username);
	}
	
	public void ssoPwd(String pwd) {
		enterText(SIGNIN_PASSWORD, pwd);
	}

	public void loginSubmitBtn() {
		click(SIGNIN_SUBMITBUTTON);
		System.out.println("User able to navigate into Home page");
	}
}