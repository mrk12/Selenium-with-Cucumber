package com.util;

public interface Setup {

	
	String CHROME_KEY="webdriver.chrome.driver";
	String CHROME_PATH="src\\test\\resources\\Config\\chromedriver.exe";
	
	String AUTOMATION_URL="https://qa-icam-e.energy.ge.com/icam-e/html/Login-cc";
	String username ="502323896";
	String pwd ="Hummer@16sp";
}
